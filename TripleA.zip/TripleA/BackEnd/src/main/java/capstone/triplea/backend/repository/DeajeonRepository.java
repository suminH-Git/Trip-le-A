package capstone.triplea.backend.repository;

import capstone.triplea.backend.entity.Deajeon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeajeonRepository extends JpaRepository<Deajeon, String> {
}
