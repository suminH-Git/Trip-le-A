-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: project_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ulsan`
--

DROP TABLE IF EXISTS `ulsan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ulsan` (
  `attraction_name` varchar(255) NOT NULL,
  `district_classification` varchar(50) DEFAULT NULL,
  `map_name_address` varchar(255) DEFAULT NULL,
  `number_address` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `area` double DEFAULT NULL,
  `public_convenience_info` varchar(255) DEFAULT NULL,
  `accommodation_info` varchar(255) DEFAULT NULL,
  `exercise_entertainment_info` varchar(255) DEFAULT NULL,
  `recreational_cultural_info` varchar(255) DEFAULT NULL,
  `hospitality_info` varchar(255) DEFAULT NULL,
  `support_info` varchar(255) DEFAULT NULL,
  `introduction` text,
  `agency_phone_number` varchar(20) DEFAULT NULL,
  `provider_organization` varchar(100) DEFAULT NULL,
  `management_organization` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`attraction_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulsan`
--

LOCK TABLES `ulsan` WRITE;
/*!40000 ALTER TABLE `ulsan` DISABLE KEYS */;
INSERT INTO `ulsan` VALUES ('간절곶 공원','관광지','울산광역시 울주군 서생면 간절곶해안길 205','울산광역시 울주군 서생면 대송리 2',35.3625312,129.3591079,584984,'주차장+화장실','펜션','산책로+카페','카페+소망우체통','','','한반도에서 가장 해가 먼저 뜨는 대표적 해맞이 장소','052-204-1754','울산광역시 울주군청','울산광역시 울주군'),('대운산 내원암 계곡','관광지','울산광역시 울주군 온양읍 대운상대길 382','울산광역시 울주군 온양읍 운화리 1312',35.39913422,129.2309807,891008,'화장실+주차장','','','산책로+사찰','','','깊고 청량한 계곡속의 수려한 연못과 폭포, 한번 누워보고 싶은 반석들을 품고 있는 비경이 있음','052-204-2345','울산광역시 울주군청','울산광역시 울주군'),('영남알프스 복합웰컴센터','관광지','울산광역시 울주군 상북면 알프스온천5길 103-8','울산광역시 울주군 상북면 등억알프스리 515-4',35.55645417,129.0679842,103604,'샤워실+화장실+주차장','모텔+리조트+캠핑장','영화관+클라이밍센터+번개맨체험관+VR체험존','영화관+카페','','영남알프스복합웰컴센터','울주 서쪽에 자리하고 있는 1,000m높이의 산들이 유럽 알프스와 견주어도 손색이 없어 많은 등산객들이 방문하고 있음','052-204-2931','울산광역시 울주군청','울산광역시 울주군'),('외고산옹기마을','관광지','울산광역시 울주군 온양읍 외고산 3길 36','울산광역시 울주군 온양읍 고산리 501-18',35.435094,129.2795067,174580,'화장실+안내소','','산책로+어린이 놀이터','옹기박물관+민속박물관+옹기아카데미관+발효아카데미관','','','전국 최대 규모의 옹기 집성촌으로 옹기를 만드는 공방과 전통 옹기 가마를 볼 수 있다.','052-204-0334','울산광역시 울주군청','울산광역시 울주군'),('울주 대곡리 반구대 암각화','관광지','울산광역시 울주군 언양읍 반구대안길 285','울산광역시 울주군 언양읍 대곡리 991',35.60863087,129.172957,117937,'암각화박물관+주차장','반구대 팜스테이','산책로','반구대 팜스테이','','관광안내소','태화강의 한 지류인 대곡천의 너비 10m, 높이 3m바위에 새겨진 그림으로 신석기 시대부터 여러시대에 걸쳐 제작된 것으로 보인다. 국보 285호','052-204-0323','울산광역시 울주군청','울산광역시 울주군'),('작괘천','관광지','','울산광역시 울주군 상북면 등억알프스리 18-2',35.55162452,129.0953395,100000,'샤워실+급수대+화장실','펜션+야영장','캠핑장+산책로','작천정+캠핑장','','','수백평이나 되는 바위가 오랜 세월의 물살에 깎여 움푹움푹 파인 형상이 마치 술잔을 걸어둔것과 같다고 해서 작괘천이라 하며, 사시사철 맑은 물이 흐른다','052-204-2346','울산광역시 울주군청','울산광역시 울주군'),('진하해수욕장','관광지','울산광역시 울주군 서생면 진하해변길 77','울산광역시 울주군 서생면 진하리 307-2',35.38384823,129.3460154,44000,'샤워실+화장실','펜션+호텔','산책로+해양스포츠','카페+식당','','진하행정봉사실','수심이 얕고,파도가 잔잔하여 가족단위 해수욕에 알맞은 울산의 대표적 해수욕장','052-204-0352','울산광역시 울주군청','울산광역시 울주군');
/*!40000 ALTER TABLE `ulsan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-21 17:23:03
