package capstone.triplea.backend.repository;

import capstone.triplea.backend.entity.Chungnam;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChungnamRepository extends JpaRepository<Chungnam, String> {
}
