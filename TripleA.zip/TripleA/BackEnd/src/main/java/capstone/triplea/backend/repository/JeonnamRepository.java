package capstone.triplea.backend.repository;

import capstone.triplea.backend.entity.Jeonnam;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JeonnamRepository extends JpaRepository<Jeonnam, String> {
}
