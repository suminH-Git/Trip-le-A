package capstone.triplea.backend.repository;

import capstone.triplea.backend.entity.Sejong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SejongRepository extends JpaRepository<Sejong,String> {
}
