package capstone.triplea.backend.service;

import capstone.triplea.backend.dto.TravelPlanerDTO;
import capstone.triplea.backend.dto.TravelPlanerListDTO;
import capstone.triplea.backend.dto.UserInputDTO;
import capstone.triplea.backend.entity.*;
import capstone.triplea.backend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class MakePlanerService {

    private final SeoulRepository seoulRepository;
    private final BusanRepository busanRepository;
    private final ChungnamRepository chungnamRepository;
    private final ChungbukRepository chungbukRepository;
    private final DaeguRepository daeguRepository;
    private final DeajeonRepository deajeonRepository;
    private final GangwondoRepository gangwondoRepository;
    private final GwangjuRepository gwangjuRepository;
    private final GyenoggidoRepository gyenoggidoRepository;
    private final GyeongnamRepository gyeongnamRepository;
    private final GyongbukRepository gyongbukRepository;
    private final IncheonRepository incheonRepository;
    private final JejuRepository jejuRepository;
    private final JeonbukRepository jeonbukRepository;
    private final JeonnamRepository jeonnamRepository;
    private final SejongRepository sejongRepository;
    private final UlsanRepository ulsanRepository;
    int strength = 0; //강도 설정

    //사용자가 입력한 3개의 데이터(지역, 여행일수, 여행강도)에 따라 3개의 랜덤한 관광지를 연결지어 여행 루틴을 만들어주는 로직
    public List<TravelPlanerListDTO> makePlanerTourist(UserInputDTO UserInputData){
        List<TravelPlanerListDTO> TravelPlanerList = new ArrayList<>();

        //총 3개 만들어서 추천해줘야함
        for(int i = 1; i<=3; i++){
            TravelPlanerListDTO travel = TravelPlanerListDTO.builder()
                    .number(i)
                    .planers(this.makeTravelPlaner(UserInputData))
                    .build();
            TravelPlanerList.add(travel);
        }

        return TravelPlanerList;
    }

    //랜덤으로 중복 안되게 여행지를 골라 각 일수와 여행강도(1,2,3)에 따라 순서를 만들어 루트를 짜줌
    public List<TravelPlanerDTO> makeTravelPlaner(UserInputDTO UserInputData){
        List<Seoul> SeoulList = this.seoulRepository.findAll();
        List<Busan> BusanList = this.busanRepository.findAll();
        List<Daegu> DaeguList = this.daeguRepository.findAll();
        List<Incheon> IncheonList = this.incheonRepository.findAll();
        List<Gwangju> GawngjuList = this.gwangjuRepository.findAll();
        List<Deajeon> DeajeonList = this.deajeonRepository.findAll();
        List<Ulsan> UlsanList = this.ulsanRepository.findAll();
        List<Sejong> SejongList = this.sejongRepository.findAll();
        List<Gyeonggido> GyeonggidoList = this.gyenoggidoRepository.findAll();
        List<Gangwondo> GangwondoList = this.gangwondoRepository.findAll();
        List<Chungbuk> ChungbukList = this.chungbukRepository.findAll();
        List<Chungnam> ChungnamList = this.chungnamRepository.findAll();
        List<Jeonbuk> JeonbukList = this.jeonbukRepository.findAll();
        List<Jeonnam> JeonnamList = this.jeonnamRepository.findAll();
        List<Gyongbuk> GyongbukList = this.gyongbukRepository.findAll();
        List<Gyeongnam> GyeongnamList = this.gyeongnamRepository.findAll();
        List<Jeju> JejuList = this.jejuRepository.findAll();

        List<TravelPlanerDTO> TravelPlaners = new ArrayList<>();

        int day = Integer.parseInt(UserInputData.getDay());
        int count = 0;

        // HashSet은 중복을 허용하지 않음
        Set<Integer> uniqueNumbers = new HashSet<>();

        Random random = new Random();
        
        //다중 if문 구현해야 함 총 14개의 지역이기에 14개 지역으로 나눠지게 됨
        //대구, 대전, 광주, 인천, 제주, 세종(아예 없음), 울산의 경우 데이터가 현저히 적어서 null 값이 잡힐 수 있기 때문에 최소 20개씩 추가해야함
        if(UserInputData.getArea().equals("서울")){
            //해당 총 서울 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(SeoulList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(SeoulList.get(strength).getAttractionName())
                            .latitude(SeoulList.get(strength).getLatitude())
                            .longitude(SeoulList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("부산")){
            //해당 총 부산 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(BusanList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(BusanList.get(strength).getAttractionName())
                            .latitude(BusanList.get(strength).getLatitude())
                            .longitude(BusanList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("대구")){
            //해당 총 대구 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(DaeguList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(DaeguList.get(strength).getAttractionName())
                            .latitude(DaeguList.get(strength).getLatitude())
                            .longitude(DaeguList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("인천")){
            //해당 총 인천 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(IncheonList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(IncheonList.get(strength).getAttractionName())
                            .latitude(IncheonList.get(strength).getLatitude())
                            .longitude(IncheonList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("광주")){
            //해당 총 광주 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(GawngjuList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(GawngjuList.get(strength).getAttractionName())
                            .latitude(GawngjuList.get(strength).getLatitude())
                            .longitude(GawngjuList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("대전")){
            //해당 총 대전 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(DeajeonList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(DeajeonList.get(strength).getAttractionName())
                            .latitude(DeajeonList.get(strength).getLatitude())
                            .longitude(DeajeonList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("울산")){
            //해당 총 울산 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(UlsanList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(UlsanList.get(strength).getAttractionName())
                            .latitude(UlsanList.get(strength).getLatitude())
                            .longitude(UlsanList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("세종")){
            //해당 총 세종 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(SejongList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(SejongList.get(strength).getAttractionName())
                            .latitude(SejongList.get(strength).getLatitude())
                            .longitude(SejongList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("경기")){
            //해당 총 경기 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(GyeonggidoList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(GyeonggidoList.get(strength).getAttractionName())
                            .latitude(GyeonggidoList.get(strength).getLatitude())
                            .longitude(GyeonggidoList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("강원")){
            //해당 총 강원 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(GangwondoList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(GangwondoList.get(strength).getAttractionName())
                            .latitude(GangwondoList.get(strength).getLatitude())
                            .longitude(GangwondoList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("충북")){
            //해당 총 충북 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(ChungbukList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(ChungbukList.get(strength).getAttractionName())
                            .latitude(ChungbukList.get(strength).getLatitude())
                            .longitude(ChungbukList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("충남")){
            //해당 총 충남 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(ChungnamList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(ChungnamList.get(strength).getAttractionName())
                            .latitude(ChungnamList.get(strength).getLatitude())
                            .longitude(ChungnamList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("전북")){
            //해당 총 전북 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(JeonbukList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(JeonbukList.get(strength).getAttractionName())
                            .latitude(JeonbukList.get(strength).getLatitude())
                            .longitude(JeonbukList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("전남")){
            //해당 총 전남 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(JeonnamList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(JeonnamList.get(strength).getAttractionName())
                            .latitude(JeonnamList.get(strength).getLatitude())
                            .longitude(JeonnamList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("경북")){
            //해당 총 경북 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(GyongbukList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(GyongbukList.get(strength).getAttractionName())
                            .latitude(GyongbukList.get(strength).getLatitude())
                            .longitude(GyongbukList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("경남")){
            //해당 총 경남 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(GyeongnamList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(GyeongnamList.get(strength).getAttractionName())
                            .latitude(GyeongnamList.get(strength).getLatitude())
                            .longitude(GyeongnamList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }
        else if (UserInputData.getArea().equals("제주")){
            //해당 총 제주 관광지 갯수를 가지고 중복이 안되게 랜덤한 숫자를 골름(해당 번호를 가지고 관광지를 골름)
            while ( uniqueNumbers.size() < (Integer.parseInt( UserInputData.getStrength() ) * day * 3) ){
                int randomNumber = random.nextInt(JejuList.size()) + 1;
                uniqueNumbers.add(randomNumber);
            }
            for(int i = 1; i<=day; i++){
                for(int j = 0; j<Integer.parseInt(UserInputData.getStrength()); j++){
                    TravelPlanerDTO TravelPlan = TravelPlanerDTO.builder()
                            .day(String.valueOf(i))
                            .order(String.valueOf(count))
                            .touristDestinationName(JejuList.get(strength).getAttractionName())
                            .latitude(JejuList.get(strength).getLatitude())
                            .longitude(JejuList.get(strength).getLongitude())
                            .build();
                    TravelPlaners.add(TravelPlan);
                    strength++;
                }
            }
        }


        return TravelPlaners;
    }
}
