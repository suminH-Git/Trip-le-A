package capstone.triplea.backend.repository;

import capstone.triplea.backend.entity.Gyeongnam;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GyeongnamRepository extends JpaRepository<Gyeongnam, String> {
}
